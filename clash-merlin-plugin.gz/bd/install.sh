#! /bin/sh

source /koolshare/scripts/base.sh


	sed -i 's/\tdetect_package/\t# detect_package/g' /koolshare/scripts/ks_tar_install.sh
	sleep 1s
echo "看到安装失败后就可以离线安装XX插件了"
echo_date 更新完毕，请等待网页自动刷新！
